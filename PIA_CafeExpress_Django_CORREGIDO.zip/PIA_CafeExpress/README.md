# PIA Café Express - Django

Proyecto web para el PIA de Fundamentos de Desarrollo Web.

## Requisitos
- Python 3.11, 3.12 o 3.13
- pip

## Windows PowerShell
Abre PowerShell dentro de esta carpeta, donde se encuentra `manage.py`.

```powershell
py -m pip install -r requirements.txt
py manage.py migrate
py manage.py createsuperuser
py manage.py runserver
```

Después abre:
http://127.0.0.1:8000/

Panel administrativo:
http://127.0.0.1:8000/admin/

## Importante
No escribas `pip install ...` dentro de `manage.py`. Los comandos de instalación y ejecución siempre se escriben en PowerShell.
